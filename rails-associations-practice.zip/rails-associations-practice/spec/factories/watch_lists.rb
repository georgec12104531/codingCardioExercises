FactoryGirl.define do
  factory :watch_list do
    
  end
end
