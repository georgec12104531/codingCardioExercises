FactoryGirl.define do
  factory :board do
    
  end
end
