FactoryGirl.define do
  factory :company do
    
  end
end
