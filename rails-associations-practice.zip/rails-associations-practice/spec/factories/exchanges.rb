FactoryGirl.define do
  factory :exchange do
    
  end
end
