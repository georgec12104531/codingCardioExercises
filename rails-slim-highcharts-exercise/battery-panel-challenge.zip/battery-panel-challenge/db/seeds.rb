# This file should contain all the record creation needed to seed the database with its default values.
# The data can then be loaded with the rails db:seed command (or created alongside the database with db:setup).
#
# Examples:
#
#   movies = Movie.create([{ name: 'Star Wars' }, { name: 'Lord of the Rings' }])
#   Character.create(name: 'Luke', movie: movies.first)


Panel.create("panel_id": 123, "battery_id": "A04", "date":  "2019-02-19", "consumption_reading": 10.4, "advisement": 600, "acceptance": 57.7)
Panel.create("panel_id": 123, "battery_id": "A04", "date":  "2019-01-05", "energy_rating": 600, "accepted": 67)
Panel.create("panel_id": 123, "battery_id": "A04", "date":  "2019-01-08","energy_rating": 600, "accepted": 67)
Panel.create("panel_id": 123, "battery_id": "A04", "date":  "2019-01-11", "consumption_reading": 9.0, "energy_rating": 800, "acceptance": 88.9, "accepted": 67)
Panel.create("panel_id": 123, "battery_id": "A04", "date":  "2019-01-13", "consumption_reading": 9.0, "energy_rating": 900, "advisement": 900, "accepted": 100)

# / <td>#{panel.battery_id}</td>
# / <td>#{panel.date}</td>
# / <td>#{panel.consumption_reading}</td>
# / <td>#{panel.energy_rating}</td>
# / <td>#{panel.advisement}</td>
# / <td>#{panel.acceptance}</td>
# / <td>#{panel.accepted}</td>
