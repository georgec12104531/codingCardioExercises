class CreatePanels < ActiveRecord::Migration[5.2]
  def change
    create_table :panels do |t|
      t.integer :panel_id
      t.integer :battery_id
      t.date :date
      t.decimal :consumption_reading
      t.integer :energy_rating
      t.integer :advisement
      t.decimal :acceptance
      t.integer :accepted
      
      t.timestamps
    end
  end
end
