class ChangeAdvismentAndBatteryIdColumns < ActiveRecord::Migration[5.2]
  def change
    change_column :panels, :battery_id, :string
  end
end
