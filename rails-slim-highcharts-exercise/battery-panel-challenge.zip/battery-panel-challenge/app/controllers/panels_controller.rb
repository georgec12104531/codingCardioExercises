class PanelsController < ApplicationController
  def index
    @panels = Panel.all 
    render :index
  end

  def create
    @panel = Panel.new(panel_params)
    if @panel.save
      render '/panels'
    else 
      render json: @panel.errors.full_messages, status: 422
    end
  end

  def show
    @panel = Panel.find(params[:id])
  end

  def edit
  end

  def update
  end

  def destroy
  end


  def panel_params
    params.require(:panel).permit(:advisement, :consumption_reading)
  end


  
end
