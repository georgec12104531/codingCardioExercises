class Battery < ApplicationRecord
  
end