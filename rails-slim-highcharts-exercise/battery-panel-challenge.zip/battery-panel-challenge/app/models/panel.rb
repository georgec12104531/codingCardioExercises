class Panel < ApplicationRecord
  
end